import { LightningElement, api } from 'lwc'; export default class TestCmpFinal extends LightningElement { @api title; @api showDetails; @api accentColor; @api count; }
